@extends('layouts.admin')
@include('partials/admin.theme.nav', ['activeTab' => 'theme'])

@section('title')
    Edit Theme
@endsection

@section('content-header')
    <h1>Theme Settings<small>Edit Sesuai Keinginan Anda</small></h1>
    <ol class="breadcrumb">
        <li><a href="{{ route('admin.index') }}">Admin</a></li>
        <li class="active">Theme</li>
    </ol>
@endsection

@section('content')
    @yield('theme::nav')
    <div class="row">
        <div class="col-xs-12">
            <div class="box">
                <div class="box-header with-border">
                    <h3 class="box-title">Backround Settings</h3>
                </div>
                <form action="{{ route('admin.theme.update') }}" method="POST">
                    <div class="box-body">
                        <div class="row">
                            <div class="form-group col-md-4">
                                <label class="control-label">Logo Pterodactyl</label>
                                <div>
                                    <input id="logo" type="text" class="form-control" name="logo" @if(!empty($theme)) value="{{ $theme->logo }}" @endif required />
                                    <p class="text-muted"><small>Logo untuk tema tersebut.</small></p>
                                </div>
                            </div>
                            <div class="form-group col-md-4">
                                <label class="control-label">Url Gambar Backround</label>
                                <div>
                                    <input id="logo" type="text" class="form-control" name="backgroundimage" @if(!empty($theme)) value="{{ $theme->backgroundimage }}" @endif required />
                                    <p class="text-muted"><small>Gambar latar belakang untuk tema tersebut.</small></p>
                                </div>
                            </div>

                        </div>
                    </div>
                    <div class="box-footer">
                        {!! csrf_field() !!}
                        <button type="submit" class="btn btn-sm btn-primary pull-right">Simpan Perubahan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endsection
